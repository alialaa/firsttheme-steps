<?php
/*
Plugin Name:  firsttheme post_types
Plugin URI:   
Description:  Adding Shortcodes for firsttheme
Version:      1.0.0
Author:       Ali Alaa
Author URI:   http://alialaa.com/
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  firsttheme-post_types
Domain Path:  /languages
*/

if( !defined('WPINC')) {
    die;
}

include_once('includes/portfolio-post-type.php');
include_once('includes/project-type-tax.php');
include_once('includes/skills-tax.php');